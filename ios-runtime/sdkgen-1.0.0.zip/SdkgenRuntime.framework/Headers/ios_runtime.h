//
//  ios_runtime.h
//  ios-runtime
//
//  Created by Arthur Hardmann on 17/06/21.
//

#import <Foundation/Foundation.h>

//! Project version number for ios_runtime.
FOUNDATION_EXPORT double ios_runtimeVersionNumber;

//! Project version string for ios_runtime.
FOUNDATION_EXPORT const unsigned char ios_runtimeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ios_runtime/PublicHeader.h>


